"""
Módulo Schemas - Validações Pydantic
"""
