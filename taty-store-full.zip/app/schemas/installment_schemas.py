from pydantic import BaseModel
from datetime import date
class InstallmentPayIn(BaseModel):
    pass
