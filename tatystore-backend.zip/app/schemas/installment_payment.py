"""
Schemas Pydantic para InstallmentPayment
Pagamentos parciais de parcelas
"""
from pydantic import BaseModel, Field, ConfigDict, computed_field, field_validator, model_validator
from datetime import datetime
from typing import Optional
from app.models.installment_payment import InstallmentPaymentStatus


class InstallmentPaymentCreate(BaseModel):
    """Schema para registrar um pagamento parcial"""
    installment_id: Optional[int] = None

    amount_paid: Optional[float] = None
    amount: Optional[float] = None

    model_config = ConfigDict(populate_by_name=True, extra='allow')

    # @model_validator(mode='after')
    # def validate_amount(self):
    #     """Valida que pelo menos um valor de pagamento foi fornecido e é válido"""
    #     print(f"[v0 VALIDATOR] amount_paid={self.amount_paid}, amount={self.amount}")

    #     # Tenta amount_paid primeiro
    #     if self.amount_paid is not None:
    #         payment_amount = self.amount_paid
    #         print(f"[v0 VALIDATOR] Usando amount_paid: {payment_amount}")
    #     elif self.amount is not None:
    #         payment_amount = self.amount
    #         print(f"[v0 VALIDATOR] Usando amount: {payment_amount}")
    #     else:
    #         # Nenhum fornecido
    #         print(f"[v0 VALIDATOR] ERRO: Nenhum valor fornecido!")
    #         raise ValueError('É necessário fornecer "amount_paid" ou "amount"')

    #     # Valida se é maior que zero
    #     if payment_amount <= 0:
    #         print(f"[v0 VALIDATOR] ERRO: Valor <= 0: {payment_amount}")
    #         raise ValueError('O valor do pagamento deve ser maior que zero')

    #     print(f"[v0 VALIDATOR] Validação OK! payment_amount={payment_amount}")
    #     return self


class InstallmentPaymentOut(BaseModel):
    """Schema para retornar dados de pagamento"""
    id: int
    installment_id: int
    amount_paid: float
    status: InstallmentPaymentStatus
    paid_at: datetime
    created_at: datetime
    
    @computed_field
    @property
    def amount(self) -> float:
        """Campo computado para compatibilidade com testes"""
        return self.amount_paid
    
    model_config = ConfigDict(from_attributes=True)


class InstallmentDetailOut(BaseModel):
    """Schema detalhado de parcela com histórico de pagamentos"""
    id: int
    sale_id: int
    customer_id: int
    company_id: int
    installment_number: int
    amount: float  # Valor original da parcela
    due_date: datetime
    status: str
    paid_at: Optional[datetime] = None
    created_at: datetime
    
    total_paid: float = 0.0  # Soma de todos os pagamentos
    remaining_amount: float = 0.0  # Valor ainda não pago
    payments: list[dict] = []  # Histórico de pagamentos
    
    model_config = ConfigDict(from_attributes=True)
