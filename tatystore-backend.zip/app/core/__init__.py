"""
Módulo Core - Configurações e Segurança
"""
