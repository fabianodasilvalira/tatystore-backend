"""
TatyStore Backend - Sistema Multi-Empresa FastAPI
"""
__version__ = "1.0.0"
