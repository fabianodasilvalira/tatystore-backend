async def notify_company_admin(background, company, user, path:str):
    return
