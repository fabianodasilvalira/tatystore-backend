from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
import sys

from app.core.database import get_db
from app.core.deps import get_current_user
from app.core.messages import Messages
from app.models.user import User
from app.models.installment import Installment, InstallmentStatus
from app.models.installment_payment import InstallmentPayment, InstallmentPaymentStatus
from app.schemas.installment_payment import (
    InstallmentPaymentCreate,
    InstallmentPaymentOut,
    InstallmentDetailOut
)
from app.schemas.installment import InstallmentOut
from app.api.v1.endpoints.installments import _calculate_installment_balance

router = APIRouter()


def paginate(data: list, total: int, skip: int, limit: int) -> dict:
    """Helper para paginar respostas"""
    return {
        "items": data,
        "total": total,
        "skip": skip,
        "limit": limit,
        "pages": (total + limit - 1) // limit if limit > 0 else 1
    }


@router.post("/", response_model=InstallmentPaymentOut, status_code=status.HTTP_201_CREATED,
             summary="Registrar pagamento de parcela")
def create_installment_payment(
        payment_data: InstallmentPaymentCreate,
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
):
    """
    Criar Pagamento de Parcela

    **Corpo da requisição:**
    \`\`\`json
    {
        "installment_id": 1,
        "amount": 100.00,
        "payment_method": "cash"
    }
    \`\`\`
    """
    print(f"[v0 ENDPOINT] create_installment_payment chamado com payment_data: {payment_data}")

    if not payment_data.installment_id:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=Messages.PAYMENT_INSTALLMENT_ID_REQUIRED
        )

    installment = db.query(Installment).filter(
        Installment.id == payment_data.installment_id
    ).first()

    if not installment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=Messages.INSTALLMENT_NOT_FOUND
        )

    if installment.company_id != current_user.company_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=Messages.RESOURCE_NOT_FOUND
        )

    amount = payment_data.amount_paid or payment_data.amount

    total_paid, remaining_amount = _calculate_installment_balance(installment)

    if amount > remaining_amount:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=Messages.format(Messages.PAYMENT_AMOUNT_EXCEEDS, amount=amount, remaining=remaining_amount)
        )

    db_payment = InstallmentPayment(
        installment_id=installment.id,
        amount_paid=amount,
        paid_at=datetime.utcnow(),
        status=InstallmentPaymentStatus.COMPLETED,
        company_id=current_user.company_id
        # payment_method=payment_data.payment_method or "cash"  # Comentado até migração
    )
    db.add(db_payment)

    new_total_paid = total_paid + amount
    if new_total_paid >= float(installment.amount):
        installment.status = InstallmentStatus.PAID
        installment.paid_at = datetime.utcnow()

    db.commit()
    db.refresh(db_payment)

    response = InstallmentPaymentOut.model_validate(db_payment)
    return response


@router.post("/{installment_id}/pay", response_model=InstallmentPaymentOut, status_code=status.HTTP_201_CREATED,
             summary="Registrar pagamento parcial")
def register_installment_payment(
        installment_id: int,
        payment: InstallmentPaymentCreate,
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
):
    """Endpoint alternativo para registrar pagamento (mantido para compatibilidade com testes)"""
    print(f"[v0 ENDPOINT] register_installment_payment chamado")
    print(f"[v0 ENDPOINT] installment_id={installment_id}")
    print(f"[v0 ENDPOINT] payment={payment}")
    print(f"[v0 ENDPOINT] payment.amount_paid={payment.amount_paid}, payment.amount={payment.amount}")

    installment = db.query(Installment).filter(
        Installment.id == installment_id
    ).first()

    if not installment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=Messages.INSTALLMENT_NOT_FOUND
        )

    if installment.company_id != current_user.company_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=Messages.RESOURCE_NOT_FOUND
        )

    amount = payment.amount_paid or payment.amount
    print(f"[v0 ENDPOINT] amount extraído: {amount}")

    if amount is None or amount <= 0:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="O valor do pagamento deve ser maior que zero"
        )

    total_paid, remaining_amount = _calculate_installment_balance(installment)

    if amount > remaining_amount:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=Messages.format(Messages.PAYMENT_AMOUNT_EXCEEDS, amount=amount, remaining=remaining_amount)
        )

    db_payment = InstallmentPayment(
        installment_id=installment_id,
        amount_paid=amount,
        paid_at=datetime.utcnow(),
        status=InstallmentPaymentStatus.COMPLETED,
        company_id=current_user.company_id
    )
    db.add(db_payment)

    new_total_paid = total_paid + amount
    if new_total_paid >= float(installment.amount):
        installment.status = InstallmentStatus.PAID
        installment.paid_at = datetime.utcnow()

    db.commit()
    db.refresh(db_payment)

    return InstallmentPaymentOut.model_validate(db_payment)


@router.get("/installments/{installment_id}/payments", response_model=dict, summary="Listar histórico de pagamentos")
def list_installment_payments(
        installment_id: int,
        skip: int = Query(0, ge=0),
        limit: Optional[int] = Query(10, ge=1),
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
):
    """
    Lista todos os pagamentos realizados para uma parcela.

    Útil para auditoria e rastreamento de quem pagou o quê e quando.
    """
    installment = db.query(Installment).filter(
        Installment.id == installment_id
    ).first()

    if not installment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=Messages.INSTALLMENT_NOT_FOUND
        )

    if installment.company_id != current_user.company_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=Messages.RESOURCE_NOT_FOUND
        )

    query = (
        db.query(InstallmentPayment)
        .filter(InstallmentPayment.installment_id == installment_id)
        .order_by(InstallmentPayment.paid_at.desc())
    )

    total = query.count()
    query = query.offset(skip)

    if limit is None:
        payments = query.all()
        limit = total if total > 0 else 1
    else:
        payments = query.limit(limit).all()

    payments_data = []
    for p in payments:
        payment_dict = InstallmentPaymentOut.model_validate(p).model_dump()
        payments_data.append(payment_dict)

    return paginate(payments_data, total, skip, limit or 10)


def _build_installment_detail_response(installment: Installment) -> InstallmentDetailOut:
    """Helper para construir resposta detalhada com histórico de pagamentos"""
    total_paid, remaining_amount = _calculate_installment_balance(installment)

    payments_data = [
        InstallmentPaymentOut.model_validate(p).model_dump()
        for p in installment.payments
        if p.status == InstallmentPaymentStatus.COMPLETED
    ]

    return InstallmentDetailOut(
        id=installment.id,
        sale_id=installment.sale_id,
        customer_id=installment.customer_id,
        company_id=installment.company_id,
        installment_number=installment.installment_number,
        amount=float(installment.amount),
        due_date=installment.due_date,
        status=installment.status,
        paid_at=installment.paid_at,
        created_at=installment.created_at,
        total_paid=total_paid,
        remaining_amount=remaining_amount,
        payments=payments_data
    )
